﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PromotionEngine.Models
{
    public class OrderSummary
    {
        public int Total { get; set; }
    }
}