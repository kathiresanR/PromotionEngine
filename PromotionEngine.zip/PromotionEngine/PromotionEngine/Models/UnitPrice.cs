﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PromotionEngine.Models
{
    public class UnitPrice
    {
        public string STUId { get; set; }
        public int? Value { get; set; }
        public int UnitQty { get; set; }
    }
}